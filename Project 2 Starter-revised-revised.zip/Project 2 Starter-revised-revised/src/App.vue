<template>
    <div class="container">
        <app-header :quoteCount="quotes.length" :maxQuotes="maxQuotes"></app-header>
        <app-newQuote @quoteAdded="newQuote"></app-newQuote>
        <app-quoteGrid :quotes="quotes" @quotesDeleted="deleteQuotes" ></app-quoteGrid>
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="alert alert-info">Info: Click on a Quote to delete it!</div>
            </div>
        </div>
    </div>
</template>

<script>
    import Header from './components/Header.vue';
    import NewQuote from './components/NewQuote.vue';
    import QuoteGrid from './components/QuoteGrid.vue';

    export default {
        data: function () {
            return {
                quotes: [
                    "Smooth seas don't make smooth sailors!"
                ],
                maxQuotes: 10
            }
        },
        methods: {
            newQuote: function(quote) {
                if(this.quotes.length >= this.maxQuotes){
                    return alert('You have too many quotes, please delete one!')
                }
                this.quotes.push(quote)
            },

            deleteQuotes: function(index) {
                this.quotes.splice(index, 1)
            }
        },
        components: {
            'app-quoteGrid': QuoteGrid,
            'app-newQuote': NewQuote,
            'app-header': Header
        }
        
    }
</script>

<style>
</style>

<template>
    <div class="col-sm-6 col-md-4 col-lg-3">
        <div class="panel panel-default">
            <div class="panel-body quote">
                <slot>{{ quote }}</slot>

                <!--ToDo: Add default slot tag for passing the quote
                unsure if this is the correct way to pass the data object, seems logical
                -->

            </div>
        </div>
    </div>
</template>

<script>
</script>

<style>
    .panel {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        color: #111;
    }

    .quote{
        cursor: pointer;
    }

    .quote:hover{
        background-color: crimson;
        opacity: 0.5;
    }
</style>
<template>
    <div class="row">
        <form>
            <div class="col-sm-8 col-sm-offset-2 col-xs-12 col-md-6 col-md-offset-3 form-group">
                <label>Quote</label>
                <textarea class="form-control" rows="3" v-model="quote"></textarea>
            </div>
            <div class="col-sm-8 col-sm-offset-2 col-xs-12 col-md-6 col-md-offset-3 form-group">
                <button class="btn btn-primary" @click.prevent="createNew" >Add Quote</button>
            </div>
        </form>
    </div>
</template>

<script>
    export default {
        data: function() {
            return {
                quote: ""
            };
        },
        methods: {
            createNew: function() {
              // New ToDo: Again you haven't created or imported an event bus, instead use this.$emit('quoteAdded, this.quote')
                this.$emit('quoteAdded, this.quote')
                this.quote = '';
            }
                // Re-initialize quote to an empty string
        }
    }
</script>

<template>
    <div class="row">


        <!--New ToDo: Make sure to pass index as a parameter in deleteQuote-->
        <!--New ToDo: Make sure to user interpolation to output the quote between the component tag-->
            {{ quote }}
        <app-quote
           v-for="index in quotes"
           @click.native="deleteQuote(index)"></app-quote>
            <!--Display the quote inside the appQuote component, in other words pass the data object to the slot in Quote.vue-->
    </div>
</template>

<script>
    import Quote from './Quote.vue';

    export default {
        props: ['quotes'],
        components: {
            'app-quote': Quote
        },
        methods: {
            deleteQuote: function(index) {
//              New ToDo: You haven't created or imported an event bus, instead use this.$emit'
                this.$emit('quotesDeleted', index )
            }
        }
    }
</script>
